#include "SARibbonUtil.h"
#include "SARibbonThemePalette.h"
#include <QFile>
#include <QWidget>
#include <QDebug>
#include <QDir>
#include <QApplication>
#include <QScreen>
#include <QGuiApplication>
#include <QStyleHints>
#include <QSettings>
#include <QProcess>
#include <QRegularExpression>
#if QT_VERSION < QT_VERSION_CHECK(5, 14, 0)
#include <QWindow>
#else
#endif
namespace SA
{

/**
 * @brief makeColorVibrant 让颜色鲜艳
 * @param c 原来的颜色
 * @param saturationDelta 增加饱和度（上限255）
 * @param valueDelta 增加明度（上限255）
 * @return
 */
QColor makeColorVibrant(const QColor& c, int saturationDelta, int valueDelta)
{
    int h, s, v, a;
    c.getHsv(&h, &s, &v, &a);  // 分解HSV分量

    // 增加饱和度（上限255）
    s = qMin(s + saturationDelta, 255);
    // 增加明度（上限255）
    v = qMin(v + valueDelta, 255);

    return QColor::fromHsv(h, s, v, a);  // 重新生成颜色
}

/**
 * @brief 按照指定的新高度，保持宽高比缩放 QSize
 *
 * 此函数根据原始尺寸的宽高比，计算出在指定新高度下的对应宽度，
 * 并返回一个新的 QSize 对象。
 *
 * @param originalSize 原始尺寸。
 * @param newHeight    缩放后的新高度。
 * @return             按比例缩放后的 QSize。
 *
 * @par 示例：
 * @code
 * QSize original(800, 600);
 * QSize scaled = scaleSizeByHeight(original, 300);
 * // scaled 将是 (400, 300)
 * @endcode
 */
QSize scaleSizeByHeight(const QSize& originalSize, int newHeight)
{
    // 检查原始尺寸高度、宽度是否有效，以及目标高度是否有效
    if (originalSize.height() <= 0 || originalSize.width() < 0 || newHeight <= 0) {
        return QSize(0, 0);  // 无效输入返回零尺寸
    }

    // 计算宽高比并缩放
    float aspectRatio = static_cast< float >(originalSize.width()) / static_cast< float >(originalSize.height());
    int newWidth      = static_cast< int >(newHeight * aspectRatio);
    return QSize(newWidth, newHeight);
}

/**
 * @brief 按照指定的新高度，宽高比为1:factor缩放 QSize。
 *
 * 此函数根据原始尺寸的宽高比，计算出在指定新高度下的对应宽度，
 * 并返回一个新的 QSize 对象。
 *
 * @param originalSize 原始尺寸。
 * @param newHeight    缩放后的新高度。
 * @param factor    宽高比 1:factor factor=1时，此函数和scaleSizeByHeight的两参数版本一样，如果factor=0.5，则宽高比为1:0.5，也就是高度扩充2倍，宽度扩充1倍
 * @return             按比例缩放后的 QSize。
 *
 * @par 示例：
 * @code
 * QSize original(800, 600);
 * QSize scaled = scaleSizeByHeight(original, 300, 2);
 * // scaled 将是 (600, 300)
 * @endcode
 */
QSize scaleSizeByHeight(const QSize& originalSize, int newHeight, qreal factor)
{
    // 1. 参数合法性检查
    if (originalSize.height() <= 0 || originalSize.width() < 0 || newHeight <= 0 || qFuzzyIsNull(factor)) {
        return QSize(0, 0);
    }

    // 2. 计算原始宽高比
    const qreal originalAspect = static_cast< qreal >(originalSize.width()) / static_cast< qreal >(originalSize.height());

    // 3. 把用户提供的 1:factor 转换成真正的目标宽高比
    //    目标宽高比 = originalAspect / factor
    const qreal targetAspect = originalAspect / factor;

    // 4. 根据新高度反推宽度
    const int newWidth = qRound(newHeight * targetAspect);

    return QSize(newWidth, newHeight);
}

/**
 * @brief 按照指定的新宽度，保持宽高比缩放 QSize。
 *
 * 此函数根据原始尺寸的宽高比，计算出在指定新宽度下的对应高度，
 * 并返回一个新的 QSize 对象。
 *
 * @param originalSize 原始尺寸。
 * @param newWidth     缩放后的新宽度。
 * @return             按比例缩放后的 QSize。
 *
 * @par 示例：
 * @code
 * QSize original(800, 600);
 * QSize scaled = scaleSizeByWidth(original, 400);
 * // scaled 将是 (400, 300)
 * @endcode
 */
QSize scaleSizeByWidth(const QSize& originalSize, int newWidth)
{
    // 检查原始尺寸宽度、高度是否有效，以及目标宽度是否有效
    if (originalSize.width() <= 0 || originalSize.height() < 0 || newWidth <= 0) {
        return QSize(0, 0);  // 无效输入返回零尺寸
    }

    // 计算高宽比并缩放
    float aspectRatio = static_cast< float >(originalSize.height()) / static_cast< float >(originalSize.width());
    int newHeight     = static_cast< int >(newWidth * aspectRatio);
    return QSize(newWidth, newHeight);
}

/**
 * \if ENGLISH
 * @brief Get the complete QSS stylesheet string for a built-in ribbon theme
 * @details Loads the base QSS, theme template, and the default palette for the given theme,
 * then returns the fully resolved stylesheet with all {{token}} placeholders replaced.
 * Returns an empty string if the theme has no template or palette.
 * \endif
 *
 * \if CHINESE
 * @brief 获取指定内置ribbon主题的完整QSS样式表字符串
 * @details 加载基础QSS、主题模板和指定主题的默认调色板，返回所有{{token}}占位符已替换的完整样式表。
 * 如果主题没有模板或调色板，则返回空字符串。
 * \endif
 */
QString getBuiltInRibbonThemeQss(SARibbonTheme theme)
{
    // Load base QSS (common styles without colors)
    QFile baseFile(":/SARibbonTheme/resource/theme-base.qss");
    QString baseQss;
    if (baseFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        baseQss = QString::fromUtf8(baseFile.readAll());
    }

    // Resolve template resource path for the theme
    auto themeToTemplatePath = [](SARibbonTheme t) -> QString {
        switch (t) {
        case SARibbonTheme::RibbonThemeOffice2016Blue:
        case SARibbonTheme::RibbonThemeOffice2016Green:
        case SARibbonTheme::RibbonThemeOffice2016Dark:
            return ":/SARibbonTheme/resource/templates/office2016.qss";
        case SARibbonTheme::RibbonThemeOffice2021Blue:
        case SARibbonTheme::RibbonThemeOffice2021Green:
        case SARibbonTheme::RibbonThemeOffice2021Dark:
            return ":/SARibbonTheme/resource/templates/office2021.qss";
        case SARibbonTheme::RibbonThemeDark:
            return ":/SARibbonTheme/resource/templates/dark.qss";
        case SARibbonTheme::RibbonThemeDark2:
            return ":/SARibbonTheme/resource/templates/dark2.qss";
        case SARibbonTheme::RibbonThemeWindows7:
            return ":/SARibbonTheme/resource/templates/win7.qss";
        case SARibbonTheme::RibbonThemeOffice2013:
            return ":/SARibbonTheme/resource/templates/office2013.qss";
        default:
            return QString();
        }
    };

    // Resolve default palette resource path for the theme
    auto themeToPalettePath = [](SARibbonTheme t) -> QString {
        switch (t) {
        case SARibbonTheme::RibbonThemeOffice2016Blue:
            return ":/SARibbonTheme/resource/palettes/office2016-blue.json";
        case SARibbonTheme::RibbonThemeOffice2016Green:
            return ":/SARibbonTheme/resource/palettes/office2016-green.json";
        case SARibbonTheme::RibbonThemeOffice2016Dark:
            return ":/SARibbonTheme/resource/palettes/office2016-dark.json";
        case SARibbonTheme::RibbonThemeOffice2021Blue:
            return ":/SARibbonTheme/resource/palettes/office2021-blue.json";
        case SARibbonTheme::RibbonThemeOffice2021Green:
            return ":/SARibbonTheme/resource/palettes/office2021-green.json";
        case SARibbonTheme::RibbonThemeOffice2021Dark:
            return ":/SARibbonTheme/resource/palettes/office2021-dark.json";
        case SARibbonTheme::RibbonThemeDark:
            return ":/SARibbonTheme/resource/palettes/dark-default.json";
        case SARibbonTheme::RibbonThemeDark2:
            return ":/SARibbonTheme/resource/palettes/dark2-default.json";
        case SARibbonTheme::RibbonThemeWindows7:
            return ":/SARibbonTheme/resource/palettes/win7-default.json";
        case SARibbonTheme::RibbonThemeOffice2013:
            return ":/SARibbonTheme/resource/palettes/office2013-default.json";
        default:
            return QString();
        }
    };

    QString templatePath = themeToTemplatePath(theme);
    QString palettePath  = themeToPalettePath(theme);
    if (templatePath.isEmpty() || palettePath.isEmpty()) {
        return baseQss;
    }

    // Load the default palette
    SARibbonThemePalette palette;
    if (!palette.loadFromFile(palettePath)) {
        qWarning() << "getBuiltInRibbonThemeQss: failed to load palette" << palettePath;
        return baseQss;
    }

    // Load template and replace tokens
    QFile templateFile(templatePath);
    if (!templateFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qWarning() << "getBuiltInRibbonThemeQss: failed to load template" << templatePath;
        return baseQss;
    }
    QString templateQss = QString::fromUtf8(templateFile.readAll());
    QString resolvedQss = replaceQssTokens(templateQss, palette);
    return baseQss + "\n" + resolvedQss;
}

/**
 * @brief 为 QIcon 生成指定 devicePixelRatio 的高分辨率 pixmap
 *
 * 之所以提供此函数，是因为 Qt5 的 QIcon::pixmap() 没有 devicePixelRatio 参数，而Qt6做了适配，为此专门提供一个兼容函数
 *
 * @param icon   图标源
 * @param size   期望的逻辑像素大小（控件坐标系）
 * @param devicePixelRatio    目标屏幕的实时 devicePixelRatio（可用 QWindow::devicePixelRatio() 获取）
 * @param mode   图标模式（Normal/Disabled/Active/Selected）
 * @param state  图标状态（On/Off）
 * @return 已设置好 devicePixelRatio 的 QPixmap，可直接 drawPixmap 使用
 */
QPixmap iconToPixmap(const QIcon& icon, const QSize& size, qreal devicePixelRatio, QIcon::Mode mode, QIcon::State state)
{
#if QT_VERSION >= QT_VERSION_CHECK(6, 0, 0)
    return icon.pixmap(size, devicePixelRatio, mode, state);
#else
    Q_UNUSED(devicePixelRatio);
    return icon.pixmap(size, mode, state);
#endif
}

/**
 * @brief 获取窗口当前所在屏幕的dpr
 * @param w
 * @return
 */
qreal widgetDevicePixelRatio(QWidget* w)
{
    if (!w) {
        return 1.0;
    }
    // 获取窗口所在的屏幕（优先当前窗口的屏幕）
    QScreen* sc = nullptr;

#if QT_VERSION < QT_VERSION_CHECK(5, 14, 0)
    if (QWindow* wh = w->windowHandle()) {
        sc = wh->screen();
    }
#else
    // 先获取窗口的顶层窗口（避免子部件直接调用screen()可能返回null的问题）
    QWidget* topWidget = w->window();
    if (topWidget) {
        sc = topWidget->screen();
    }
#endif
    if (!sc) {
        // qApp->primaryScreen() 拿到的是“整个系统里被用户标记成 primary 的那一块屏,是“全局主屏”
        sc = QApplication::primaryScreen();
    }
    if (!sc) {
        return 1.0;
    }
    return sc->devicePixelRatio();
}

/**
 * \if ENGLISH
 * @brief Check if the application layout direction is Right-to-Left (RTL)
 * @return true if layout direction is Qt::RightToLeft, false otherwise
 * \endif
 *
 * \if CHINESE
 * @brief 检查应用程序布局方向是否为从右到左（RTL）
 * @return 如果布局方向为 Qt::RightToLeft 返回 true，否则返回 false
 * \endif
 */
bool saIsRTL()
{
    return QApplication::layoutDirection() == Qt::RightToLeft;
}

/**
 * \if ENGLISH
 * @brief Mirror X coordinate for RTL layout support
 * @param x The original X coordinate
 * @param containerWidth The width of the container
 * @param elementWidth The width of the element
 * @return containerWidth - x - elementWidth when RTL, x unchanged when LTR
 * \endif
 *
 * \if CHINESE
 * @brief 为 RTL 布局支持镜像 X 坐标
 * @param x 原始 X 坐标
 * @param containerWidth 容器宽度
 * @param elementWidth 元素宽度
 * @return RTL 时返回 containerWidth - x - elementWidth，LTR 时返回 x 不变
 * \endif
 */
int saMirrorX(int x, int containerWidth, int elementWidth)
{
    if (saIsRTL()) {
        return containerWidth - x - elementWidth;
    }
    return x;
}

/**
 * @brief Check if the operating system uses dark mode
 *
 * Detects dark mode via three tiers:
 * 1. Qt 6.5+: Uses QGuiApplication::styleHints()->colorScheme()
 * 2. Qt < 6.5 Windows: Reads registry AppsUseLightTheme
 * 3. Qt < 6.5 macOS: Runs 'defaults read -g AppleInterfaceStyle'
 * 4. Qt < 6.5 Linux: Runs 'gsettings get org.gnome.desktop.interface color-scheme'
 * 5. All other cases: Returns false (assume light mode)
 *
 * @return true if OS dark mode is active, false otherwise
 */
bool isOperatingSystemInDarkMode()
{
#if QT_VERSION >= QT_VERSION_CHECK(6, 5, 0)
    // Qt 6.5+ has native cross-platform API
    return QGuiApplication::styleHints()->colorScheme() == Qt::ColorScheme::Dark;
#elif defined(Q_OS_WIN32)
    // Windows: Read registry AppsUseLightTheme
    // DWORD value 0 = dark mode, 1 = light mode
    // Registry path: HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize
    QSettings settings(
        "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize",
        QSettings::NativeFormat);
    bool ok = false;
    int value = settings.value("AppsUseLightTheme", 1).toInt(&ok);
    return (ok && value == 0);
#elif defined(Q_OS_MACOS)
    // macOS: Run 'defaults read -g AppleInterfaceStyle'
    // Returns "Dark" if dark mode is active, empty otherwise
    QProcess process;
    process.start("/usr/bin/defaults", QStringList() << "read" << "-g" << "AppleInterfaceStyle");
    process.waitForFinished(3000);
    QString output = QString::fromUtf8(process.readAllStandardOutput()).trimmed();
    return output.contains("Dark", Qt::CaseInsensitive);
#elif defined(Q_OS_LINUX)
    // Linux: Try gsettings for GNOME 42+
    // Returns "dark" or "prefer-dark" in dark mode
    QProcess process;
    process.start("gsettings", QStringList() << "get" << "org.gnome.desktop.interface" << "color-scheme");
    process.waitForFinished(3000);
    QString output = QString::fromUtf8(process.readAllStandardOutput()).trimmed();
    return output.contains("dark", Qt::CaseInsensitive);
#else
    // Unknown platform or headless: assume light mode
    return false;
#endif
}

/**
 * @brief Replace {{token}} and {{token|opacity(value)}} patterns in QSS templates with actual color values
 * @param templateQss The QSS template string containing tokens
 * @param palette The theme palette providing color values
 * @return The QSS string with all tokens replaced
 */
QString replaceQssTokens(const QString& templateQss, const SARibbonThemePalette& palette)
{
    QString result = templateQss;

    QRegularExpression re("\\{\\{([^}|]+)(?:\\|opacity\\(([^)]+)\\))?\\}\\}");

    // First pass: collect all token matches and their replacements
    struct TokenMatch
    {
        qsizetype start;
        qsizetype length;
        QString replacement;
    };
    QVector<TokenMatch> matches;

    QRegularExpressionMatchIterator it = re.globalMatch(result);
    while (it.hasNext()) {
        QRegularExpressionMatch match  = it.next();
        QString           tokenName    = match.captured(1);
        QString           opacityStr   = match.captured(2);
        QString           raw          = palette.rawValue(tokenName);

        QString replacement;
        if (!raw.isEmpty()) {
            QColor color(raw);
            if (color.isValid()) {
                if (!opacityStr.isEmpty()) {
                    bool  ok;
                    float opacity = opacityStr.toFloat(&ok);
                    if (ok) {
                        int alpha       = qRound(opacity * 255);
                        replacement = QString("#%1%2").arg(alpha, 2, 16, QChar('0')).arg(color.name().mid(1));
                    } else {
                        replacement = color.name();
                    }
                } else {
                    replacement = color.name();
                }
            } else {
                // Non-color raw string (e.g. qlineargradient(...)) — use directly
                replacement = raw;
            }
        }

        if (!replacement.isEmpty()) {
            matches.append({ match.capturedStart(), match.capturedLength(), replacement });
        }
    }

    // Apply replacements in reverse order to preserve offsets
    for (qsizetype i = matches.size() - 1; i >= 0; --i) {
        result.replace(matches[i].start, matches[i].length, matches[i].replacement);
    }

    // Scan for any unreplaced tokens and warn about them
    {
        QRegularExpression                unreplacedRe("\\{\\{([^}|]+)(?:\\|opacity\\([^)]+\\))?\\}\\}");
        QRegularExpressionMatchIterator   warnIt = unreplacedRe.globalMatch(result);
        while (warnIt.hasNext()) {
            QRegularExpressionMatch warnMatch = warnIt.next();
            qWarning() << "replaceQssTokens: unreplaced token:" << warnMatch.captured(1).trimmed();
        }
    }

    return result;
}

}
