# SARibbon 开发指引

## 禁止事项

- **禁止读取或修改** `src/SARibbon.cpp` 和 `src/SARibbon.h` — 这是 amalgamate 工具生成的合并文件，所有源码改动应在 `src/SARibbonBar/` 下进行
- **禁止** `slots`/`signals`/`emit` → 用 `Q_SLOTS`/`Q_SIGNALS`/`Q_EMIT`
- **禁止** 头文件 public 函数加双语 Doxygen → 仅用单行英文 `///`
- **禁止** Q_PROPERTY 上加任何注释（分组注释如 `// == Ribbon properties ==` 可以）
- **禁止** 类注释用 `@param`/`@class`/`@ingroup` → 仅 `@brief`/`@details`/`@note`/`@see`
- **禁止** `as any`/`@ts-ignore` 类型的类型安全压制（本项目无 TypeScript，但精神一致：不压制编译错误）

## 项目结构

```
src/SARibbonBar/          ← 所有源码（.h/.cpp），这是唯一应编辑的目录
src/SARibbon.cpp/.h       ← ⛔ 合并文件，禁止触碰
src/SARibbonBar/colorWidgets/  ← SAColorWidgets 子模块（SAColorToolButton等）
src/SARibbonBar/3rdparty/      ← 第三方代码
src/SARibbonBar/i18n/          ← 翻译文件 (.ts/.qm)
example/                  ← 示例程序（MainWindowExample是最主要的）
tests/                    ← 单元测试（Qt Test框架，需 BUILD_TESTS=ON）
tools/                    ← Amalgamate合并工具，以及Python绑定构建脚本
sip/                      ← PyQt5 SIP绑定定义文件（.sip）
pyqt6/sip/                ← PyQt6 SIP绑定定义文件（独立维护）
pyside6/                  ← PySide6绑定（Shiboken6）：CMakeLists.txt、typesystem XML、glue代码
pyexamples/               ← Python示例程序（pyqt5/pyqt6/pyside6三个子目录）
pyproject.toml            ← PyQt5 PyPI打包配置
pyproject-pyqt6.toml      ← PyQt6 PyPI打包配置
pyside6/pyproject.toml    ← PySide6 PyPI打包配置
docs/zh/dev-guide/        ← 开发规范文档（编码前必读）
docs/zh/build-guide/      ← 构建指引
docs/zh/python-guide/     ← Python绑定文档（中文）
docs/en/python-guide/     ← Python绑定文档（英文）
```

核心头文件 `src/SARibbonBar/SARibbonGlobal.h` 定义了：`SA_RIBBON_EXPORT`、`SA_RIBBON_DECLARE_PRIVATE`/`SA_RIBBON_DECLARE_PUBLIC`、`SA_RIBBON_IMPL_CONSTRUCT`、`SA_D`/`SA_DC`/`SA_Q`/`SA_QC`、`SARibbonAlignment`/`SARibbonTheme`/`SARibbonMainWindowStyleFlag` 枚举。

## 构建

CMake 构建，最低 Qt 5.12，支持 Qt5 和 Qt6，C++ 标准由 CMakeLists 根据 Qt 版本和选项自动设定（最低 C++14）。完整构建指引见 [build.md](build.md)。

### 构建环境

- **Windows**：CMake 3.15+，Visual Studio 2019（MSVC 14.29+）或 2022（MSVC 14.34+），Qt 6.7+ 或 Qt 5.12+
- **Linux / WSL**：CMake 3.15+，GCC 9+（推荐 GCC 13+），Qt 6.x（apt）或 Qt 5.12+（手动安装）

### 快速构建（推荐使用 scripts/build.ps1 脚本）

Windows 下推荐使用 `scripts/build.ps1` 脚本，自动检测 Qt 路径和 MSVC 版本，并自动处理 VS 生成器选择：

```powershell
.\scripts\build.ps1                          # full: configure + build + install (Release)
.\scripts\build.ps1 build                    # 增量编译（跳过 configure）
.\scripts\build.ps1 rebuild                  # 清理并重新构建（clean + configure + build + install）
.\scripts\build.ps1 configure -Examples OFF  # 仅库，不编示例
.\scripts\build.ps1 configure -StaticLibs ON # 静态库
.\scripts\build.ps1 install                  # 执行 install（build 后运行）
.\scripts\build.ps1 help                     # 查看所有选项
```

脚本支持的全部参数：`-Examples`、`-Tests`、`-StaticLibs`、`-Frameless`、`-SnapLayout`（均接受 `ON`/`OFF`），以及 `-QtPath`、`-VSVersion`、`-Config`。详细构建指引见 [build.md](build.md)。

Linux/WSL 快速构建：

```bash
sudo apt install qt6-base-dev qt6-base-dev-tools qt6-svg-dev qt6-tools-dev ninja-build
cmake -S . -B build-linux -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build-linux --parallel
```

> 构建损坏时先关掉 `build/bin` 下占用的程序，再删除 build 目录重配。Linux apt 安装的 Qt6 无需指定 `CMAKE_PREFIX_PATH`。

### vcpkg 构建

项目支持 vcpkg manifest 模式，`vcpkg.json` 声明了依赖，`CMakePresets.json` 提供了预设配置：

```bash
# 使用 vcpkg preset 构建（自动拉取依赖）
cmake --preset=vcpkg-msvc-x64-release
cmake --build --preset=vcpkg-msvc-x64-release
```

vcpkg 的 `frameless` feature 会自动启用 `SARIBBON_USE_FRAMELESS_LIB`。

### CMake 选项

| 选项 | 默认值 | 说明 |
|------|--------|------|
| `SARIBBON_BUILD_STATIC_LIBS` | OFF | 静态库，ON 时自动定义 `SA_RIBBON_BAR_NO_EXPORT` |
| `SARIBBON_USE_FRAMELESS_LIB` | OFF | 使用 QWindowKit 无边框方案，需 C++17 和 QWindowKit 库 |
| `SARIBBON_BUILD_EXAMPLES` | ON | 控制是否编译示例程序 |
| `SARIBBON_ENABLE_SNAPLAYOUT` | OFF | 启用 Windows 11 Snap Layout（仅 frameless 模式有效） |
| `SARIBBON_INSTALL_IN_CURRENT_DIR` | ON (Windows) | 安装到 `bin_qt{版本}_{编译器}_x{架构}/` |
| `BUILD_TESTS` | OFF | 启用单元测试（Qt Test 框架） |

> 根据实际 Qt 安装位置调整 `CMAKE_PREFIX_PATH`。

## 注释规范（强制，AI代码尤其容易违反）

| 位置 | 格式 | 规则 |
|------|------|------|
| .h public函数 | `// Get the category name` | 单行英文，禁止双语Doxygen |
| .h Q_PROPERTY | 无注释 | 禁止任何Doxygen块 |
| .h 类注释 | 双语 `\if ENGLISH`/`\if CHINESE` | 仅 `@brief`/`@details`/`@note`/`@see` |
| .h 信号注释 | 双语 `\if ENGLISH`/`\if CHINESE` | 信号没有.cpp定义，注释必须在头文件 |
| .cpp 函数实现 | 双语 `\if ENGLISH`/`\if CHINESE` | 详细注释放.cpp，不放.h |

## PIMPL 模式

所有核心类使用 PIMPL，宏来自 `SARibbonGlobal.h`：

```cpp
// .h — 紧跟 Q_OBJECT 之后
class SA_RIBBON_EXPORT SARibbonCategory : public QFrame
{
    Q_OBJECT
    SA_RIBBON_DECLARE_PRIVATE(SARibbonCategory)  // 生成 d_ptr + PrivateData前置声明
    // Q_PROPERTY 不加注释
    Q_PROPERTY(bool isCanCustomize READ isCanCustomize WRITE setCanCustomize)
public:
    // Constructor
    explicit SARibbonCategory(QWidget* p = nullptr);
};

// .cpp — PrivateData 定义在cpp中（不在.h中）
class SARibbonCategory::PrivateData
{
    SA_RIBBON_DECLARE_PUBLIC(SARibbonCategory)  // 生成 q_ptr 反向指针
public:
    PrivateData(SARibbonCategory* p);
    bool enableShowPanelTitle { true };  ///< 行尾注释标记成员
};

// 构造函数 — 项目惯用 d_ptr(new ...) 而非 SA_RIBBON_IMPL_CONSTRUCT
SARibbonCategory::SARibbonCategory(QWidget* p)
    : QFrame(p), d_ptr(new SARibbonCategory::PrivateData(this))
{
}

// 函数体中
void SARibbonBar::showMinimumModeButton(bool isShow)
{
    SA_D(d);   // 非const: PrivateData* d = d_ptr.get()
    // const函数用 SA_DC(d)
}
```

PIMPL 注意：`d_ptr` 用 `std::unique_ptr`（非 QScopedPointer），PrivateData 析构必须在 .cpp 可见。私有成员变量全在 PrivateData 中，不在 .h 的类体中。

## Qt 集成要点

- 属性用 `Q_PROPERTY` 暴露（布尔getter用 `is*` 前缀如 `isMinimumMode()`）
- 信号命名：`xxxChanged` 模式（`ribbonStyleChanged`、`categoryNameChanged`）
- 信号发射：`Q_EMIT`（禁止 `emit`）
- 槽可见性：`public Q_SLOTS`/`protected Q_SLOTS`/`private Q_SLOTS`

## 格式化

`.clang-format` 基于 WebKit 风格，4空格缩进，120字符行宽，指针靠左（`QWidget* p`），CRLF换行。**注意**：SARibbonAlignment枚举要求文件换行为CRLF，LF会导致编译错误。

## Git 提交格式

```
修复：SARibbonCategory布局计算错误

- 修复了在紧凑模式下面板高度计算不正确的问题
- 相关文件：SARibbonCategory.cpp, SARibbonCategoryLayout.cpp
- 关联计划：Ribbon布局优化计划
```

## 开发规范文档（编码前必读）

| 文档 | 内容 |
|------|------|
| [coding-standards.md](docs/zh/dev-guide/coding-standards.md) | 命名规范、Doxygen注释、Git提交 |
| [pimpl-dev-guide.md](docs/zh/dev-guide/pimpl-dev-guide.md) | PIMPL宏完整用法 |
| [qt-integration.md](docs/zh/dev-guide/qt-integration.md) | Q_PROPERTY、信号槽、Qt宏 |
| [build-SARibbon.md](docs/zh/build-guide/build-SARibbon.md) | CMake构建选项详解 |