#include <QtTest>
#include <QApplication>
#include "SARibbonBar.h"
#include "SARibbonCategory.h"
#include "SARibbonPanel.h"
#include "SARibbonGlobal.h"

class SARibbonCategoryLayoutRTLTest : public QObject
{
    Q_OBJECT

private slots:
    void testPanelOrderInRTL();
    void testScrollButtonsInRTL();
};

void SARibbonCategoryLayoutRTLTest::testPanelOrderInRTL()
{
    SARibbonBar ribbonBar;
    ribbonBar.resize(800, 200);
    SARibbonCategory* category = ribbonBar.addCategoryPage("Test Category");
    SARibbonPanel* panel1      = category->addPanel("Panel 1");
    SARibbonPanel* panel2      = category->addPanel("Panel 2");
    SARibbonPanel* panel3      = category->addPanel("Panel 3");

    ribbonBar.show();
    QApplication::processEvents();

    // LTR mode
    QApplication::setLayoutDirection(Qt::LeftToRight);
    QApplication::processEvents();
    QRect panel1RectLTR = panel1->geometry();
    QRect panel2RectLTR = panel2->geometry();
    QRect panel3RectLTR = panel3->geometry();

    // Verify panels are ordered left to right
    QVERIFY(panel1RectLTR.left() < panel2RectLTR.left());
    QVERIFY(panel2RectLTR.left() < panel3RectLTR.left());

    // Switch to RTL mode
    QApplication::setLayoutDirection(Qt::RightToLeft);
    QApplication::processEvents();
    QRect panel1RectRTL = panel1->geometry();
    QRect panel2RectRTL = panel2->geometry();
    QRect panel3RectRTL = panel3->geometry();

    // Verify panels are ordered right to left
    QVERIFY(panel1RectRTL.left() > panel2RectRTL.left());
    QVERIFY(panel2RectRTL.left() > panel3RectRTL.left());

    // Verify panel widths are preserved (allow tolerance for platform style differences)
    QVERIFY(qAbs(panel1RectLTR.width() - panel1RectRTL.width()) <= 15);
    QVERIFY(qAbs(panel2RectLTR.width() - panel2RectRTL.width()) <= 15);
    QVERIFY(qAbs(panel3RectLTR.width() - panel3RectRTL.width()) <= 15);

    // Reset to LTR
    QApplication::setLayoutDirection(Qt::LeftToRight);
}

void SARibbonCategoryLayoutRTLTest::testScrollButtonsInRTL()
{
    SARibbonBar ribbonBar;
    ribbonBar.resize(400, 200);  // Small width to force scrolling
    SARibbonCategory* category = ribbonBar.addCategoryPage("Test Category");

    // Add many panels to force scroll
    for (int i = 0; i < 10; ++i) {
        category->addPanel(QString("Panel %1").arg(i + 1));
    }

    ribbonBar.show();
    QApplication::processEvents();

    // LTR mode - scroll buttons should be at right
    QApplication::setLayoutDirection(Qt::LeftToRight);
    QApplication::processEvents();
    QList< QAbstractButton* > scrollButtonsLTR = category->findChildren< QAbstractButton* >();
    QVERIFY(scrollButtonsLTR.size() >= 2);  // Left and right scroll buttons

    // Find rightmost button in LTR
    int maxLeftLTR = 0;
    for (QAbstractButton* btn : scrollButtonsLTR) {
        maxLeftLTR = std::max(maxLeftLTR, btn->geometry().left());
    }
    QVERIFY(maxLeftLTR > ribbonBar.width() / 2);  // Rightmost button on right side

    // RTL mode - scroll buttons should be at left
    QApplication::setLayoutDirection(Qt::RightToLeft);
    QApplication::processEvents();
    QList< QAbstractButton* > scrollButtonsRTL = category->findChildren< QAbstractButton* >();
    QVERIFY(scrollButtonsRTL.size() >= 2);

    // Find leftmost button in RTL
    int minLeftRTL = ribbonBar.width();
    for (QAbstractButton* btn : scrollButtonsRTL) {
        minLeftRTL = std::min(minLeftRTL, btn->geometry().left());
    }
    QVERIFY(minLeftRTL < ribbonBar.width() / 2);  // Leftmost button on left side

    // Reset to LTR
    QApplication::setLayoutDirection(Qt::LeftToRight);
}

QTEST_MAIN(SARibbonCategoryLayoutRTLTest)

#include "SARibbonCategoryLayoutRTLTest.moc"
